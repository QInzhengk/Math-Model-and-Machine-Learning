
public class Demo {
    public static void main(String[] args) {
        System.out.println("+--------------------------+");
        System.out.println(" |                   ��ӭ��½����ѧԺ��վ                     |");
        System.out.println("|                          |");
        System.out.println("|    www.mingrisoft.com    |");
        System.out.println("|                          |");
        System.out.println("+--------------------------+");
    }
}
