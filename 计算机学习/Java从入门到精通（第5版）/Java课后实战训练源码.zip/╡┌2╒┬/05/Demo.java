
public class Demo {
    public static void main(String[] args) {
        System.out.println("&&&&&&&&&&&&&&&&");
        System.out.println("&       �ҵ�δ��������       &");
        System.out.println("&&&&&&&&&&&&&&&&");
    }
}
