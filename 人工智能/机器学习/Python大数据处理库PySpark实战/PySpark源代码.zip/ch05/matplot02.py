import matplotlib
import matplotlib.pyplot as plt
import numpy as np

#支持中文，否则乱码
plt.rcParams['font.family'] = ['sans-serif']
plt.rcParams['font.sans-serif'] = ['SimHei']

#准备数据
np.random.seed(20170907)
mu = 100  # 均值
sigma = 15  # 标准差
x = mu + sigma * np.random.randn(1024)
num_bins = 50
fig, ax = plt.subplots()
#设置窗口标题
fig.canvas.set_window_title('直方图示例')
#直方图数据
n, bins, patches = ax.hist(x, num_bins, density=1)
#添加'best fit'线
y = ((1 / (np.sqrt(2 * np.pi) * sigma)) *
     np.exp(-0.5 * (1 / sigma * (bins - mu))**2))
#绘图,折线图
ax.plot(bins, y, '--')
#坐标轴设置
ax.set_xlabel('人数')
ax.set_ylabel('概率密度')
ax.set_title(r'$\mu=100$, $\sigma=15$')

#调整间距以防止ylabel剪切
fig.tight_layout()
#当前目录下保存图片
fig.savefig("histogram.png")
#显示图片
plt.show()
