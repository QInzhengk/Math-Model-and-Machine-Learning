
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, to_timestamp
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ETL") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
df = spark.read.csv('./ml-small/ratings.csv',header=True,inferSchema=True)
df.show(10)
df.printSchema()
df.summary().show()
#df.select("rating").summary().show()
#打印资料的行数量和列数量
print(df.count(),len(df.columns))
#删除所有列的空值和NaN
dfNotNull=df.na.drop()
print(dfNotNull.count(),len(dfNotNull.columns))
#创建视图movie
df.createOrReplaceTempView("movie")
#spark sql
df2 = spark.sql("select count(*) as counter, rating from \
  movie group by rating order by rating asc")
df2.show()
##############################################
from matplotlib import pyplot as plt 
#Pandas >= 0.19.2 must be installed
pdf = df2.toPandas()
x = pdf["rating"]
y = pdf["counter"]
plt.xlabel("rating")
plt.ylabel("counter")
plt.title("movie rating")
plt.bar(x,y)
#显示数值标签
for x1,y1 in zip(x,y):
  plt.text(x1, y1+0.05, '%.0f' % y1, ha='center', va= 'bottom',fontsize=11)
plt.show()
##############################################
sc.stop()