
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import to_date, to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import from_unixtime
from pyspark.sql.types import DateType
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ETL") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc) 
df = spark.read.csv('./ml-small/ratings.csv',header=True).cache()

df.printSchema()
df.show()

df = df.withColumn("rating", df.rating.cast("double"))
#df = df.withColumn("datetime", df.timestamp.cast(DateType()))
#df = df.withColumn("datetime",from_unixtime(df.timestamp.cast("bigint"), 'yyyy-MM-dd HH:mm:ss.SSS'))
df = df.withColumn("date",from_unixtime(df.timestamp.cast("bigint"), 'yyyy-MM-dd'))


df.printSchema()
df.show()


import numpy as np 
from matplotlib import pyplot as plt 
import matplotlib
from pyspark.sql.types import DateType
 
df.createOrReplaceTempView("movie")

df2 = spark.sql("select count(*) as counter, rating from movie group by rating order by rating desc")
df2.show()
#Pandas >= 0.19.2 must be installed
pdf = df2.toPandas()
#pdf.show()
x = pdf["rating"][1:10]
y = pdf["counter"][1:10]
plt.xlabel("x")
plt.ylabel("y")
plt.plot(x,y) 
plt.show()
##############################################
