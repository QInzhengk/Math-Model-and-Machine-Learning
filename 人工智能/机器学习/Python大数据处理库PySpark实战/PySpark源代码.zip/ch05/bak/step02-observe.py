
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import to_timestamp
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ETL") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc) 
df = spark.read.csv('./ml-small/ratings.csv',header=True)

df.printSchema()
df.show()

df = df.withColumn("rating", df.rating.cast("double"))
df = df.withColumn("timestamp", to_timestamp(df.timestamp, 'yyyy-MM-dd HH:mm:ss'))
df.printSchema()
df.summary().show()
##############################################
