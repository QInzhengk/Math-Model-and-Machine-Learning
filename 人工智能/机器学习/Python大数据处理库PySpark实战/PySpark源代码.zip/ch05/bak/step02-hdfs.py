
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import to_timestamp
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ETL") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc) 
df = spark.read.json('hdfs://localhost:9700/mydata/user.json')

df.printSchema()
df.show()
# root
#  |-- age: long (nullable = true)
#  |-- deptId: string (nullable = true)
#  |-- gender: string (nullable = true)
#  |-- name: string (nullable = true)
#  |-- salary: long (nullable = true)

# +---+------+------+-----+------+
# |age|deptId|gender| name|salary|
# +---+------+------+-----+------+
# | 32|    01|    男| 张三|  5000|
# | 33|    01|    男| 李四|  6000|
# | 38|    01|    女| 王五|  5500|
# | 42|    02|    男| Jack|  7000|
# | 27|    02|    女|Smith|  6500|
# | 45|    02|    女| Lily|  9500|
# +---+------+------+-----+------+
# df = df.withColumn("rating", df.rating.cast("double"))
# df = df.withColumn("timestamp", to_timestamp(df.timestamp, 'yyyy-MM-dd HH:mm:ss'))
# df.printSchema()
# df.summary().show()
##############################################
