from pyspark import *

# 将输入映射为key-value键值对
def mapToPairs(line):
    res = line.split(',')
    return (res[0], float(res[1]))

# 根据key值求和
def add(a,b):
     return a+b

# 对每个partition取前top k
def select_top_k(it):
    k = broadcast_k.value
    sorted_res = sorted(it, key=lambda x: x[1], reverse=True)
    top_k_res = [0] * k
    i = 0
    for t in sorted_res:
        top_k_res[i] = t
        i += 1
        if i >= k:
            break
    return top_k_res

data_path = 'data/arrays.txt'
out_path = 'sortResult.txt'
k_value = 10
# 设置master url，初始化SC
sc = SparkContext('local', 'TopK')
# 创建共享变量，保存k的值
broadcast_k = sc.broadcast(k_value)
# 进行MapReduce操作
rdd = sc.textFile(data_path)\
          .map(mapToPairs)  \
          .reduceByKey(add) \
          .mapPartitions(select_top_k)
top_k_res = rdd.takeOrdered(k_value, key=lambda x: -x[1])
# 输出结果
with open(out_path, 'w') as out:
    for i in top_k_res:
        out.write(i[0] + '\n')