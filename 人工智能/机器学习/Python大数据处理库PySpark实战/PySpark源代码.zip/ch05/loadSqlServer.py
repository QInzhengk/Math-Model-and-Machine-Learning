
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, to_timestamp
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ETL") \
        .getOrCreate();
#############################################
df = spark.read.csv('./ml-small/ratings.csv',header=True).cache()
df = df.withColumn("rating", df.rating.cast("double"))
df = df.withColumn("date",from_unixtime(df.timestamp.cast("bigint"), 'yyyy-MM-dd'))
df = df.withColumn("date",df.date.cast("date"))
df = df.drop("timestamp")
df2 = spark.read.csv('./ml-small/movies.csv',header=True).cache()
df3 = df.join(df2, df.movieId == df2.movieId,"inner") \
        .select("userId",df.movieId,"title","date","rating").cache()
from pyspark.sql.functions import udf
def isLike(v):
    if v > 4:
        return True
    else:
        return False
from pyspark.sql.types import BooleanType
udf_isLike=udf(isLike,BooleanType())
df3 = df3.withColumn("isLike",udf_isLike(df3["rating"]))
from pyspark.sql.functions import pandas_udf, PandasUDFType
@pandas_udf("string", PandasUDFType.GROUPED_AGG) 
def fmerge(v):
    return ','.join(v)

df5 = spark.read.csv('./ml-small/tags.csv',header=True).cache()
df5 = df5.drop("timestamp")
df7 = df5.groupBy(["userId","movieId"]).agg(fmerge(df5["tag"])).cache()
df7 = df7.withColumnRenamed("fmerge(tag)","tags")
df6 = df3.join(df7,(df3.movieId == df7.movieId) & (df3.userId == df7.userId))\
        .select(df3.userId,df3.movieId,"title","date","tags","rating","isLike") \
        .orderBy(["date"], ascending=[0]).cache()
df6 = df6.filter(df.date>'2015-10-25').cache()
#save to file
db_url = "jdbc:sqlserver://localhost:1433;databaseName=bg_data;user=root;password=root"
db_table = "movie"
#overwrite会重新生成表 append
df6.write.mode("overwrite").jdbc(db_url, db_table)
##############################################
spark.stop()