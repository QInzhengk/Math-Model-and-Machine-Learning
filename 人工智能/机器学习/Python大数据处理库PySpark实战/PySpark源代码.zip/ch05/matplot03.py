import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
#支持中文，否则乱码
plt.rcParams['font.family'] = ['sans-serif']
plt.rcParams['font.sans-serif'] = ['SimHei']
# 解决保存图像时负号'-'显示为方块的问题
plt.rcParams['axes.unicode_minus'] = False 
# plt.rcParams['savefig.dpi'] =300
# plt.rcParams['figure.dpi'] = 300 
# 分配2x2个区域进行绘图
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
#设置窗口标题
fig.canvas.set_window_title('多图示例')
#############################################
#第1个图绘制
delta = 0.025
x = np.arange(-3.0, 3.0, delta)
y = np.arange(-2.0, 2.0, delta)
X, Y = np.meshgrid(x, y)
Z1 = np.exp(-X**2 - Y**2)
Z2 = np.exp(-(X - 1)**2 - (Y - 1)**2)
Z = (Z1 - Z2) * 2
CS = ax1.contour(X, Y, Z)
ax1.clabel(CS, inline=1, fontsize=10)
ax1.set(title='等高线')
#第2个图绘制
x = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
y1 = [6, 5, 8, 5, 6, 6, 8, 9, 8, 10]
y2 = [5, 3, 6, 4, 3, 4, 7, 4, 4, 6]
y3 = [4, 1, 2, 1, 2, 1, 6, 2, 3, 2]
#柱状图
ax2.bar(x, y1, label="label1", color='red')
ax2.bar(x, y2, label="label2",color='orange')
ax2.bar(x, y3, label="label3", color='green')
ax2.set(title='柱状图',ylabel='数量',xlabel='类型')
#第3个图绘制
w = 3
Y, X = np.mgrid[-w:w:100j, -w:w:100j]
U = -1 - X**2 + Y
V = 1 + X - Y**2
speed = np.sqrt(U**2 + V**2)
gs = gridspec.GridSpec(nrows=3, ncols=2, height_ratios=[1, 1, 2])
#streamplot
ax3.streamplot(X, Y, U, V, density=[0.5, 1])
ax3.set_title('密度')

#第4个图绘制
np.random.seed(20170907)
N = 100
r0 = 0.6
x = 0.9 * np.random.rand(N)
y = 0.9 * np.random.rand(N)
area = (20 * np.random.rand(N))**2 
c = np.sqrt(area)
r = np.sqrt(x ** 2 + y ** 2)
area1 = np.ma.masked_where(r < r0, area)
area2 = np.ma.masked_where(r >= r0, area)
ax4.scatter(x, y, s=area1, marker='^', c=c)
ax4.scatter(x, y, s=area2, marker='o', c=c)
theta = np.arange(0, np.pi / 2, 0.01)
ax4.plot(r0 * np.cos(theta), r0 * np.sin(theta))
ax4.set_title('分类示例')
###################################################
fig.tight_layout()
fig.savefig("muliPlot.png")
plt.show()