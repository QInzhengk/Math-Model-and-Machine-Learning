sum = lambda x, y: x + y
#3
print(sum(1,2))
#9
print((lambda x:x**2)(3))
#定义列表
a = [('b',3),('a',2),('d',4),('c',1)]
#[('a', 2), ('b', 3), ('c', 1), ('d', 4)]
print(sorted(a,key=lambda x:x[0]))
a = [('a',(7,3)),('a',(1,7)),('c',(2,5)),('d',(5,9))]
#[('a', (1, 7)), ('c', (2, 5)), ('d', (5, 9)), ('a', (7, 3))]
print(sorted(a,key=lambda x:x[1]))
#[('a', (7, 3)), ('c', (2, 5)), ('a', (1, 7)), ('d', (5, 9))]
print(sorted(a,key=lambda x:x[1][1]))
#[0, 1, 4, 9, 16]
print(list(map(lambda x: x*x,[y for y in range(5)])))
names = ['Jack', 'Joly', 'Bob', 'Smith']
fnames= filter(lambda x: x.startswith('J'),names)
#['Jack', 'Joly']
print(list(fnames))
msg = "Hello Spark!"
words = msg.split(' ')
items  = map(lambda x:(x,1),words)
#[('Hello', 1), ('Spark!', 1)]
print(list(items))
# 导入reduce
from functools import reduce 
#reduce要求表达式是2个参数
#45=0+1+2+...+9
print(reduce((lambda x,y: x+y),range(10)))
#定义一个函数
def printReduce(x,y):
    #用于调试，很方便
    print("x={}".format(x))
    print("y={}".format(y))
    #返回一个有2个元素的元组
    return (x[0]+" " + y[0],x[1]+y[1])
result = reduce(printReduce,[('Hello', 1), ('Spark!', 2)],('Init',0))
#['Init Hello Spark!', 3]
print(list(result))
##############################################
# 求N!,如6!= 6*5*4*3*2*1
nmh = lambda x, y: x * y
# 求每个阶乘的组成的列表
lam2 = lambda a: reduce(nmh,range(1,a+1))
# 求列表的和
sum = lambda m, n: m + n
#求6!+5!+4!+3!+2!+1!的和
#873
print(reduce(sum,list(map(lam2,range(1,7)))))