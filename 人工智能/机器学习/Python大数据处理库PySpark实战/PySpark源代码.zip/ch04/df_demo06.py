
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .config("spark.sql.shuffle.partitions",4) \
        .getOrCreate();
sc = spark.sparkContext
#############################################
conf = sc.getConf().get("spark.sql.shuffle.partitions")
print(conf)
strlen = spark.udf.register("strLen", lambda x: len(x))
a = [('Jack', 32),('Smith', 33),('李四', 36)]
rdd = sc.parallelize(a)
df = spark.createDataFrame(rdd, "name: string, age: int")
df.createOrReplaceTempView("user")
df2 = spark.sql("select *,strLen(name) as len from user")
df2.show()
# +-----+---+---+
# | name|age|len|
# +-----+---+---+
# | Jack| 32|  4|
# |Smith| 33|  5|
# | 李四| 36|  2|
# +-----+---+---+
##############################################
