
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
x = sc.parallelize([("a", 1), ("b", 4)])
y = sc.parallelize([("a", 2), ("c", 8)])
rdd = x.fullOuterJoin(y)
# [('b', (4, None)), ('c', (None, 8)), ('a', (1, 2))]
print(rdd.collect())
##############################################
sc.stop()