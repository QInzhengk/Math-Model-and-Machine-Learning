
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(["a","b","c"])
#获取元素数量
#3
print(rdd.count())
rdd =sc.parallelize([["a","b"],"c"])
#2
print(rdd.count())
##############################################
sc.stop()