
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4, 5,6])
rdd = rdd.filter(lambda x: x % 2 == 0)
#[2, 4, 6]
print(rdd.collect())
##############################################
sc.stop()