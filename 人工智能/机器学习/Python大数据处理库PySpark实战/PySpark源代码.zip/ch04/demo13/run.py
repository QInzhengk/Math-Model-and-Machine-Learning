from calc.m_sum  import sum
#12
print(sum(3,4,5))
from calc.m_prod  import prod
#60
print(prod(3,4,5))
from calc.m_prod  import _prod
#60
print(prod(3,4,5))
from calc.m_prod  import __prod
#60
print(prod(3,4,5))
from calc.m_sum  import Name
#Jack
print(Name)
from calc.m_sum  import __version
#1.0
print(__version)
from calc.m_sum  import _name
#JackWang
print(_name)