#import *无法导入单下划线和双下划线打头命名的变量和方法
from calc.m_sum  import *
from calc.m_prod  import *
#12
print(sum(3,4,5))
#Jack
print(Name)
#60
print(prod(3,4,5))
####################
#'_name' is not defined
# print(_name)
# print(__version)
# print(_prod(3,4,5))
# print(__prod(3,4,5))
