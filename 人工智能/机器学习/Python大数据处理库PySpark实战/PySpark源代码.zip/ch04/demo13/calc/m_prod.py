def prod(*args):
   v = 1
   for var in args:
      v *= var
   return v
def _prod(*args):
   v = 1
   for var in args:
      v *= var
   return v
def __prod(*args):
   v = 1
   for var in args:
      v *= var
   return v
print("m_prod load")
