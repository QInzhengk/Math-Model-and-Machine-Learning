_name = "JackWang"
__version = "1.0"
Name ="Jack"
def sum( *args):
   v = 0
   for var in args:
      v += var
   return v
print("m_sum load")
