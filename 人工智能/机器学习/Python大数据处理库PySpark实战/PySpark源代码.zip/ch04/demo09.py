#算符运算符
a = 32
b = 7.5
#39.5
print (a + b)
#24.5
print (a-b)
#240.0
print (a * b)
#4.266666666666667
print (a / b)
#2.0返回除法的余数
print (a % b)
b = 3
#32768
print (a**b)
#10取整除
c = a//b 
print (c)
#比较运算符
#True
print (a>b)
#False
print (a==b)
#True
print (a!=b)
#逻辑运算符
#如果a为False，返回False，否则它返回b的值
#返回b的值3
print ( a and b)
#如果a是True，它返回a的值，否则它返回b的值
#返回a的值32
print ( a or b)
#False
print ( not b)
#成员运算符
list = [1, 2, 3, 4, 5 ]
#True
print (2 in list)
#True
print (10 not in list)
#身份运算符
a = 30
b = 30
#True
print (a is b)
#False
print (a is not b)