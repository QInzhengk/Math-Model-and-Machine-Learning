
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 2), ("a", 3),("b", 5)])
def f(x):
        # ('a', 1)
        # ('b', 2)
        # ('a', 3)
        # ('b', 5)
        print(x)
        return (x[0],x[1]*2)
ret = rdd.foreach(f)
#None
print(ret)
#############################################
sc.stop()

