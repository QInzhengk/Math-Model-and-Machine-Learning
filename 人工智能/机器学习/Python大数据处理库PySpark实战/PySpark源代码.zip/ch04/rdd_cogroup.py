
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a= sc.parallelize([("a", 1), ("b", 4)])
b = sc.parallelize([("a", 2)])
ret = [(x, tuple(map(list, y))) for x, y in sorted(list(a.cogroup(b).collect()))]
#[('a', ([1], [2])), ('b', ([4], []))]
print(ret)
##############################################
sc.stop()