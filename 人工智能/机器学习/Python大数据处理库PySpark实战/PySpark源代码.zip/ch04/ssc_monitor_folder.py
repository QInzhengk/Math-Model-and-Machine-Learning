
import findspark
findspark.init()
##############################################
#d定义累加函数
def updateAccWordCount(newValues, runningCount):
    if runningCount is None:
        runningCount = 0
    return sum(newValues, runningCount) 

from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[2]") \
        .appName("StreamingContext Demo") \
        .getOrCreate();
sc = spark.sparkContext
from pyspark.streaming import StreamingContext
##间隔
ssc = StreamingContext(sc, 7)
ssc.checkpoint('spark-ssc-wc')
#############################################
lines = ssc.textFileStream("file:///E:/pyspark_book/src/ch04/log")
words = lines.flatMap(lambda line: line.split(" "))
pairs = words.map(lambda word: (word, 1))
accWordCounts = pairs.updateStateByKey(updateAccWordCount)
accWordCounts.pprint()
##############################################
#启动Spark Streaming
ssc.start() 
ssc.awaitTermination()
# -------------------------------------------
# Time: 2020-05-10 11:00:11
# -------------------------------------------
# ('hello', 2)
# ('pyspark', 2)

# -------------------------------------------
# Time: 2020-05-10 11:00:18
# -------------------------------------------
# ('hello', 3)
# ('pyspark', 3)

# -------------------------------------------
# Time: 2020-05-10 11:00:25
# -------------------------------------------
# ('hello', 5)
# ('pyspark', 5)

# -------------------------------------------
# Time: 2020-05-10 11:00:32
# -------------------------------------------
# ('hello', 6)
# ('pyspark', 6)

