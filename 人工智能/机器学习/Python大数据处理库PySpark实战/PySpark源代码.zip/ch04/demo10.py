#input函数接受一个标准输入，返回string类型
#int函数将string类型转换成int类型
print("########if条件判断语句########")
age = int(input("请输入年龄: "))
#if条件判断语句
if age <= 0 or age > 150 :
    print("年龄{0}只能在0~150之间".format(age))
elif age > 0 and age <= 14:
    print("年龄{0}在0~14之间".format(age))
elif age > 14 and age <= 18:
    print("年龄{0}在14~18之间".format(age))
else:
    print("年龄{0}大于18".format(age))

print("########for循环语句########")
list = ["C", "Spark", "Go", "Python"] 
#for...in变量list
for x in list:
    print (x)

print("########while循环语句########")
num = int(input("请输入一个数(3的倍数直接退出): "))
#while循环语句
while 1:
    print("输入的数为{0}".format(num))
    if num % 3 == 0:
        break
    else:
        num = int(input("再次输入一个数: "))
print("########for循环continue########")
for letter in 'Hello Python!':   
   if letter == '!' or letter == ' ': 
      continue
   print ('字母 :', letter)
print("########for in range循环########")
sum = 0
#0...10
for n in range(0, 11):
    #print(n)
    sum += n
#55
print("0~10求和=",sum)
