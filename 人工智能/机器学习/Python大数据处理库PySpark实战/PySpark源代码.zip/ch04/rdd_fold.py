
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
ret=sc.parallelize([1, 2, 3, 4, 5]).fold(0, lambda x,y:x+y)
#15
print(ret)
ret=sc.parallelize([1, 2, 3, 4, 5]).fold(1, lambda x,y:x*y)
#120
print(ret)
##############################################
sc.stop()