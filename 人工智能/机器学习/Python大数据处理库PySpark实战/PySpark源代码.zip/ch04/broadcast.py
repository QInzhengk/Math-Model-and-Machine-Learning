
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
conf = {"ip":"192.168.1.1","key":"cumt"}
#广播变量
brVar =  sc.broadcast(conf)
#获取广播变量值
a = brVar.value
#{'ip': '192.168.1.1', 'key': 'cumt'}
print(a)
#cumt
print(a["key"])
#更新广播变量
brVar.unpersist()
conf["key"] = "jackwang"
#再次广播
brVar =  sc.broadcast(conf)
#获取广播新变量值
a = brVar.value
#{'ip': '192.168.1.1', 'key': 'jackwang'}
print(a)
#destroy()可将广播变量的数据和元数据一同销毁，销毁后不能使用
brVar.destroy()
##############################################
sc.stop()