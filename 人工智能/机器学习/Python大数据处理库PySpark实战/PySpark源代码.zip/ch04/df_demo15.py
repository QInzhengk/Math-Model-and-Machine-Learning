
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
#注意：json数组不能有[]
df = spark.read.format('json') \
        .load('user.json')
#打印字段的类型
print(df.dtypes)
df.show()

#透视
df2 = df.groupBy("deptId") \
        .pivot("gender") \
        .sum("salary")

df2.show()

#条件选择
df.select("name",df.salary.between(6000,9500)).show()
df.select("name","age").where(df.name.like("Smi%")).show()

"""
[('age', 'bigint'), ('deptId', 'string'), ('gender', 'string'), ('name', 'string'), ('salary', 'bigint')]
+---+------+------+-----+------+
|age|deptId|gender| name|salary|
+---+------+------+-----+------+
| 32|    01|    男| 张三|  5000|
| 33|    01|    男| 李四|  6000|
| 38|    01|    女| 王五|  5500|
| 42|    02|    男| Jack|  7000|
| 27|    02|    女|Smith|  6500|
| 45|    02|    女| Lily|  9500|
+---+------+------+-----+------+

+------+-----+-----+
|deptId|   女|   男|
+------+-----+-----+
|    01| 5500|11000|
|    02|16000| 7000|
+------+-----+-----+

+-----+---------------------------------------+
| name|((salary >= 6000) AND (salary <= 9500))|
+-----+---------------------------------------+
| 张三|                                  false|
| 李四|                                   true|
| 王五|                                  false|
| Jack|                                   true|
|Smith|                                   true|
| Lily|                                   true|
+-----+---------------------------------------+

+-----+---+
| name|age|
+-----+---+
|Smith| 27|
+-----+---+

"""