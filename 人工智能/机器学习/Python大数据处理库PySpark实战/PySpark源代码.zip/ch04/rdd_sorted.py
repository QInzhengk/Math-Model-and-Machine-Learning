
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
#[4, 3, 20, 2, 10]
#TypeError: 'RDD' object is not iterable
print(sorted(sc.parallelize([10,20,3,4,2])))
##############################################
sc.stop()