
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([3, 4, 5])
fm= rdd.flatMap(lambda x: range(1, x))
#[1, 2, 1, 2, 3, 1, 2, 3, 4]
print(fm.collect())
fm = rdd.flatMap(lambda x: [(x, x), (x, x)])
#[(3, 3), (3, 3), (4, 4), (4, 4), (5, 5), (5, 5)]
print(fm.collect())
##############################################
sc.stop()