
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 2),("b", 3)])
def f(x,y):
        #1 2
        #1 3
        print(x,y)
        return x + y
#rdd2 = rdd.reduceByKey(lambda x,y:x+y)
rdd2 = rdd.reduceByKey(f)
#[('a', 3), ('b', 4)]
print(rdd2.collect())
##############################################
sc.stop()