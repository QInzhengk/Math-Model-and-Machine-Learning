
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(range(2,10))
#[5, 9, 5, 3, 2, 2, 7, 7, 5, 7, 9, 9, 5, 3, 2, 4, 5, 5, 6, 8]
#True代表一个元素可以出现多次
print(rdd.takeSample(True, 20, 1))
#[5, 8, 3, 7, 9, 2, 6, 4]
#False代表一个元素只能出现1次
print(rdd.takeSample(False, 20, 1))
##############################################
sc.stop()
