
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(["b", "a", "c", "d"])
rdd2 = rdd.map(lambda x: (x, 1))
#[('b', 1), ('a', 1), ('c', 1), ('d', 1)]
print(rdd2.collect())
##############################################
sc.stop()