
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(range(100), 1)
#按照2:3比例进行RDD切分
rdd1, rdd2 = rdd.randomSplit([2, 3], 10)
#40
print(len(rdd1.collect()))
#60
print(len(rdd2.collect()))
##############################################
sc.stop()