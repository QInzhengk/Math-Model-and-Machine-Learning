str = "python"
#字符串截取
str01 = str[0:]
#python
print(str01)
#python
print(str[:])
#yt
print(str[1:3])
#pyt
print(str[:3])
#h
print(str[3])
#pto
print(str[0:5:2])
#*******
print("*"*7)
#字符串拼接
#hello python
print("hello "+str)