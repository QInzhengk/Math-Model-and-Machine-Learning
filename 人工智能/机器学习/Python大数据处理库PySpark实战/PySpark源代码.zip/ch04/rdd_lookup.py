
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a = range(100)
rdd = sc.parallelize(zip(a, a), 2)
#[32]
print(rdd.lookup(32))
sorted = rdd.sortByKey()
#[32]
print(sorted.lookup(32))
# []
print(sorted.lookup(200))
rdd = sc.parallelize([('a', 'b'), ('c', 'd')])
#['b']
print(rdd.lookup('a'))
rdd = sc.parallelize([['a', 'b'], ['c', 'd']])
#['b']
print(rdd.lookup('a'))
rdd = sc.parallelize([(('a', 'b'), 'c')])
#['c']
print(rdd.lookup(('a', 'b')))
#错误
#rdd = sc.parallelize([1,2,3]).lookup(1)
##############################################
sc.stop()