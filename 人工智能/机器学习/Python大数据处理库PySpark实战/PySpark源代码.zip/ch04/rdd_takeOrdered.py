
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(range(2,100))
#[2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
print(rdd.takeOrdered(10))
#[99, 98, 97, 96, 95, 94, 93, 92, 91, 90]
print(rdd.takeOrdered(10, key=lambda x: -x))
##############################################
sc.stop()