import findspark
findspark.init()

##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
##############################################
rdd = sc.parallelize([1, 2])
rdd2 = sc.parallelize([3, 7])
rdd3 = sorted(rdd.cartesian(rdd2).collect())
#[(1, 3), (1, 7), (2, 3), (2, 7)]
print(rdd3)
rdd4 = sorted(rdd2.cartesian(rdd).collect())
#[(3, 1), (3, 2), (7, 1), (7, 2)]
print(rdd4)
##############################################
sc.stop()