
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd1 = sc.parallelize([("a",1),("b",2),("a",3)])
#['a', 'b', 'a']
print(rdd1.keys().collect())
rdd1 = sc.parallelize([["a",1],["b",2],["a",3]])
#['a', 'b', 'a']
print(rdd1.keys().collect())
##############################################
sc.stop()