
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", ["hello", "spark", "!"]), ("b", ["cumt"])])
def f(x): 
        #['hello', 'spark', '!']
        #['cumt']
        print(x)
        return len(x)
rdd2 = rdd.mapValues(f)
#[('a', 3), ('b', 1)]
print(rdd2.collect())
##############################################
sc.stop()