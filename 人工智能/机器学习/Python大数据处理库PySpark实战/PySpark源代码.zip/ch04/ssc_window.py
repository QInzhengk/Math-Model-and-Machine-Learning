
import findspark
findspark.init()
##############################################
#d定义累加函数
def updateAccWordCount(newValues, runningCount):
    if runningCount is None:
        runningCount = 0
    return sum(newValues, runningCount) 

from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[2]") \
        .appName("StreamingContext Demo") \
        .getOrCreate();
sc = spark.sparkContext
from pyspark.streaming import StreamingContext
##3间隔
ssc = StreamingContext(sc, 3)
ssc.checkpoint('spark-ssc-wc')
#############################################
lines = ssc.socketTextStream("localhost", 7777)
words = lines.flatMap(lambda line: line.split(" "))
pairs = words.map(lambda word: (word, 1))
#E:\wmsoft\netcat-win32-1.12>nc -L -v -p 7777
#windowDuration must be multiple of the slide duration (3000 ms)
accWordCounts = pairs.window(6,3).updateStateByKey(updateAccWordCount)
accWordCounts.pprint()
##############################################
#启动Spark Streaming
ssc.start() 
ssc.awaitTermination()

# -------------------------------------------
# Time: 2020-05-10 13:36:36
# -------------------------------------------
# ('world', 2)
# ('hello', 3)
# ('spark', 1)

# -------------------------------------------
# Time: 2020-05-10 13:36:39
# -------------------------------------------
# ('world', 3)
# ('hello', 5)
# ('spark', 2)

# -------------------------------------------
# Time: 2020-05-10 13:36:42
# -------------------------------------------
# ('world', 4)
# ('hello', 7)
# ('spark', 2)
# ('pyspark', 1)