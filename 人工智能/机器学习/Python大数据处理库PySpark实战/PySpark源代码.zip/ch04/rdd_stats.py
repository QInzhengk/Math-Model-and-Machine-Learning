
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(range(100))
#(count: 100, mean: 49.5, stdev: 28.86607004772212, max: 99, min: 0)
print(rdd.stats())
##############################################
sc.stop()