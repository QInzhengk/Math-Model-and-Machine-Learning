#!/usr/local/bin/python3
msg = "hello python"
print(msg)