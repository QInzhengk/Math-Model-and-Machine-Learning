
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a = [   ('01','张三', '男',32,5000),
        ('01', None, '男',33,6000),
        ('01','王五', '女',36,None),
        ('02','Jack', '男',42,7000),
        ('02','Smith', '女',27,6500),
        ('02','Lily', '女',45,None),
]
rdd = sc.parallelize(a)
peopleDf = spark.createDataFrame(rdd,\
   "deptId:string,name:string,gender:string,age:int,salary:int")
#None值显示为null
peopleDf.show()
#将空值进行替换
peopleDf.na.fill({'salary': 0, 'name': 'unknown'}).show()

# +------+-----+------+---+------+
# |deptId| name|gender|age|salary|
# +------+-----+------+---+------+
# |    01| 张三|    男| 32|  5000|
# |    01| null|    男| 33|  6000|
# |    01| 王五|    女| 36|  null|
# |    02| Jack|    男| 42|  7000|
# |    02|Smith|    女| 27|  6500|
# |    02| Lily|    女| 45|  null|
# +------+-----+------+---+------+

# +------+-------+------+---+------+
# |deptId|   name|gender|age|salary|
# +------+-------+------+---+------+
# |    01|   张三|    男| 32|  5000|
# |    01|unknown|    男| 33|  6000|
# |    01|   王五|    女| 36|     0|
# |    02|   Jack|    男| 42|  7000|
# |    02|  Smith|    女| 27|  6500|
# |    02|   Lily|    女| 45|     0|
# +------+-------+------+---+------+
##############################################
