
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.range(1,10,2)
#[1, 3, 5, 7, 9]
print(rdd.collect())
#spark-rdd是目录,且不能存在此目录
rdd.saveAsTextFile("c://spark-rdd2")
##############################################
sc.stop()