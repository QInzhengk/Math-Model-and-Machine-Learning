
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4], 3)
ret = sorted(rdd.glom().collect())
#[[1], [2], [3, 4]]
print(ret)
##############################################
sc.stop()