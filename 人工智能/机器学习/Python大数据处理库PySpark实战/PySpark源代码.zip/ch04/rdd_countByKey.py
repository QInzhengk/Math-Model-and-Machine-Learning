
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 2), ("a", 3)])
#[('a', 2), ('b', 1)]
print(sorted(rdd.countByKey().items()))
##############################################
sc.stop()