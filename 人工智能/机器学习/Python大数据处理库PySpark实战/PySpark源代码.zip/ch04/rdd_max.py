
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(["a","b","c"])
#max()获取元素最大值
#c
print(rdd.max())
rdd =sc.parallelize([1,2,3])
#3
print(rdd.max())
##############################################
sc.stop()