#从模块demo14(demo14.py)文件中导入类peole
from demo14 import people
#继承people
class student(people):
    grade = ''
    def __init__(self,name,age,height,grade):
        #调用父类的构函
        people.__init__(self,name,age,height)
        self.grade = grade
    #覆写父类的方法
    def speak(self):
        print("%s age is %d,grade is %s" %(self.name,self._age,self.grade))
#实例化
stu = student("jack",32,178,3)
#jack age is 32,grade is 3
stu.speak()
#jack height is 178
stu._speak()
#jack
print(stu.name)
#32
print(stu._age)
#'student' object has no attribute '__height'
#print(stu.__height)
#'student' object has no attribute '__speak'

