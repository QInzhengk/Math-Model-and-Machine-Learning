#字符串
var01 = "my name is jack"
print(var01)
#id获取内存地址
print(id(var01))
#整型
var01 = 32
#id获取内存地址
print(id(var01))
print(var01)
#浮点型
var01 = 32.89
print(var01)
#列表
var01 = [1,2,3,4,5,6]
print(var01)
#元组
var01 =(1,1,2,3)
print(var01)
#字典
var01 ={"name":"jack","age":32}
print(var01)
#多个变量赋值
a, b, c = 7, 3.14, "jack"
print(a,b,c)
#删除变量
del a