import findspark
findspark.init()

##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
##############################################
data=[1,3,5,7,9,11,13,15,17]
#2个分区
rdd=sc.parallelize(data,2)
#打印分区的值
print(rdd.glom().collect())
seqOp = (lambda x, y: (x[0] + y, x[1] + 1))
combOp = (lambda x, y: (x[0] + y[0], x[1] + y[1]))
a=rdd.aggregate((0,0),seqOp,combOp)
#(81, 9)=(0,0)+(16,4)+(65,5)
print(a)
#求每个分区的最大值的和
fmax = lambda x, y : ( x[0] if x[0] > y else y , x[1]+1)
# zeroValue初始值形式是(x,y)
a=rdd.aggregate((0,0),fmax,combOp)
#(24, 9)=(0,0)+(7,4)+(17,5)
print(a)
#求每个分区的最小值的和
fmin = lambda x, y : ( x[0] if x[0] < y else y , x[1]+1)
a=rdd.aggregate((6,0),fmin,combOp)
#第一个分区和6比较，最小值是1
#第二个分区和6比较，最小值是6
#(13, 9)= (6,0)+(1,4)+(6,5)
print(a)
##############################################
sc.stop()