#python脚本示例
msg = "hello python"
print(msg)