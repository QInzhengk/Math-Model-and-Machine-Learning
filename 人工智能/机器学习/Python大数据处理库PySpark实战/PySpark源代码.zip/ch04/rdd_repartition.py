
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1,2,3,4,5,6,7], 3)
#[[1, 2], [3, 4], [5, 6, 7]]
print(rdd.glom().collect())
#[[1, 2, 5, 6, 7], [3, 4]]
print(rdd.repartition(2).glom().collect())
#[[], [1, 2], [], [], [5, 6, 7], [3, 4]]
print(rdd.repartition(6).glom().collect())
##############################################
sc.stop()