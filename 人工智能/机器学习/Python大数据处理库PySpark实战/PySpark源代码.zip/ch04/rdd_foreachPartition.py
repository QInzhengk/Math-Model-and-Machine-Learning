
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
def f(iter):
    for x in iter:
         print(x)

sc.parallelize([1, 2, 3, 4, 5,6,7,8],2).foreachPartition(f)

def f2(x):
        print(x)
        
sc.parallelize([1, 2, 3, 4, 5,6,7,8],2).foreach(f2)
##############################################
sc.stop()