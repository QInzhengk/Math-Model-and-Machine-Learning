
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 3), ("a", 2),("b", 4)],2)
#rdd = sc.parallelize([("a", 1), ("b", 3), ("a", 2),("b", 4)],2)
def to_list(a):
    #print(a)
    return [a]

def append(a, b):
    print(a)
    print(b)
    a.append(b)
    return a

def extend(a, b):
    print("======")
    print(a)
    print(b)
    a.extend(b)
    return a

ret = sorted(rdd.combineByKey(to_list, append, extend).collect())
#[('a', [1, 2]), ('b', [3, 4])]
print(ret)
##############################################
sc.stop()