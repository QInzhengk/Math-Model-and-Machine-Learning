myName = "JackWang"
my_age = 32
print(myName);print(my_age);