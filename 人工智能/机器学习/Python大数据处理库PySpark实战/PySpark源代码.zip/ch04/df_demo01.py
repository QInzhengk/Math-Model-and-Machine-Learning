
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
#############################################
a = [('Jack', 32),('Smith', 33)]
df = spark.createDataFrame(a)
#[Row(_1='Jack', _2=32), Row(_1='Smith', _2=33)]
print(df.collect())
df.show()
# +-----+---+
# |   _1| _2|
# +-----+---+
# | Jack| 32|
# |Smith| 33|
# +-----+---+
df2 = spark.createDataFrame(a, ['name', 'age'])
#[Row(name='Jack', age=32), Row(name='Smith', age=33)]
print(df2.collect())
df2.show()
# +-----+---+
# | name|age|
# +-----+---+
# | Jack| 32|
# |Smith| 33|
# +-----+---+
##############################################
