
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(["a","a","c"])
#distinct()去重
#['a', 'c']
print(rdd.distinct().collect())
##############################################
sc.stop()