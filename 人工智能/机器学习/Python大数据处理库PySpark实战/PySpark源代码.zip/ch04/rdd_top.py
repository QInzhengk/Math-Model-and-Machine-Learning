
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd =sc.parallelize(range(2,100))
#top(N)首先降序排列，并获取前N个元素
#[99, 98, 97, 96, 95, 94, 93, 92, 91, 90]
print(rdd.top(10))
#[4, 3, 20, 2, 10]
print(sc.parallelize([10,20,3,4,2]).top(10,key=str))
##############################################
sc.stop()