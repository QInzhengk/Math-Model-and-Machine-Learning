#字典
dict01 = {'name': "jack", 'age': 32, 'isman': True}
#{'name': 'jack', 'age': 32, 'isman': True}
print(dict01)
#修改值
dict01["name"] = "JackWang"
#{'name': 'JackWang', 'age': 32, 'isman': True}
print(dict01)
#添加值
dict01["height"] = 1.78
#{'name': 'JackWang', 'age': 32, 'isman': True, 'height': 1.78}
print(dict01)
#JackWang
print(dict01["name"])
#{'name': 'JackWang', 'age': 32, 'isman': True, 'height': 1.78}
print(str(dict01))
#4
print(len(dict01))
#dict_keys(['name', 'age', 'isman', 'height'])
print(dict01.keys())
#dict_values(['JackWang', 32, True, 1.78])
print(dict01.values())
k, v = dict01.popitem()
#height 1.78
print(k, v) 
#删除
del dict01["name"]
#{'age': 32, 'isman': True, 'height': 1.78}
print(dict01)
#True
print('isman' in dict01) 
a = [('a', 1.58), ('b', 1.29), ('c', 2.19)]
#转换成字典
dicta = dict(a)
#{'a': 1.58, 'b': 1.29, 'c': 2.19}
print(dicta)
b = [['a', 1.58], ['b', 1.29], ['c', 2.19]]
#转换成字典
dictb = dict(b)
#{'a': 1.58, 'b': 1.29, 'c': 2.19}
print(dictb)
#查看dict的方法:['setdefault', 'update', 'values',...]
print(dir(dict))
#字符串模板
tpl = 'Name:%(name)s, Price:%(price).2f'
book = {'name':'Python', 'price': 69}
#Name:Python, Price:69.00
print(tpl % book)
#删除
del dict01