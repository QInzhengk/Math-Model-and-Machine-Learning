import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
#0...999
rdd =sc.parallelize(range(1000))
#缓存
rdd.cache()
#最大值999
print(rdd.max())
##############################################
sc.stop()