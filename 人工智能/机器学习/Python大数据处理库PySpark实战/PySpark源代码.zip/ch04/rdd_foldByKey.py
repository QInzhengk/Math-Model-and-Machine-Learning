
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 2), ("a", 3),("b", 5)])
rdd2=rdd.foldByKey(0, lambda x,y:x+y)
# [('a', 4), ('b', 7)]
print(rdd2.collect())
rdd3=rdd.foldByKey(1, lambda x,y:x*y)
# [('a', 3), ('b', 10)]
print(rdd3.collect())
##############################################
sc.stop()

