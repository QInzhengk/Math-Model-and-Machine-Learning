import json
#字典类型转换为JSON
map1 = {
    'name' : "jack",
    'age' : 32,
    'likes' : ['movie','car']
}
json_str = json.dumps(map1)
#{"name": "jack", "age": 32, "likes": ["movie", "car"]}
print (json_str)
#JSON转换为字典
map2 = json.loads(json_str)
#jack
print (map2['name'])
#['movie', 'car']
print (map2['likes'])
