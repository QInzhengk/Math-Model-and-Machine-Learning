#单行注释
'''
这是多行注释
这是多行注释
'''
str1 = 'Jack'
str2 = "你好\n"
str3 =  """hello python
hello spark"""
#\符号将一行的语句分为多行显示
total = str1 + \
        str2 + \
        str3
#语句中包含 [], {} 或 () 可以直接多行显示
nums = [1, 2, '3',
        '4', '5']
#缩进一致
if True:
    print(total)
    print(nums)