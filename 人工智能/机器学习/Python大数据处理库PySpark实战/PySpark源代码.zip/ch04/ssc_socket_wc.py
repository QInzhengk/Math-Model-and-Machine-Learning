
import findspark
findspark.init()
##############################################
#d定义累加函数
def updateAccWordCount(newValues, runningCount):
    if runningCount is None:
        runningCount = 0
    return sum(newValues, runningCount) 

from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[2]") \
        .appName("StreamingContext Demo") \
        .getOrCreate();
sc = spark.sparkContext
from pyspark.streaming import StreamingContext
##1秒间隔
ssc = StreamingContext(sc, 1)
ssc.checkpoint('spark-ssc-wc')
#############################################
lines = ssc.socketTextStream("localhost", 7777)
words = lines.flatMap(lambda line: line.split(" "))
pairs = words.map(lambda word: (word, 1))
#E:\wmsoft\netcat-win32-1.12>nc -L -v -p 7777
#累加
accWordCounts = pairs.updateStateByKey(updateAccWordCount)
accWordCounts.pprint()
#wordCounts = pairs.reduceByKey(lambda x, y: x + y)
#wordCounts.pprint()
#wordCounts.saveAsTextFiles("ssc_socket_wc")
##############################################
#启动Spark Streaming
ssc.start() 
ssc.awaitTermination()

# -------------------------------------------
# Time: 2020-05-10 10:16:28
# -------------------------------------------
# ('hadoop', 1)
# ('hello', 2)
# ('spark', 1)

# -------------------------------------------
# Time: 2020-05-10 10:16:29
# -------------------------------------------
# ('hadoop', 1)
# ('hello', 3)
# ('spark', 2)

# -------------------------------------------