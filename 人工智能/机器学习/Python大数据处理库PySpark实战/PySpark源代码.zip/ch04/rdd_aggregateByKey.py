import findspark
findspark.init()

##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
##############################################
data=[("a",1),("b",2),("a",3),("b",4),("a",5),("b",6),("a",7),("b",8),("a",9),("b",10)]
#2个分区
rdd=sc.parallelize(data,2)
#打印分区的值
#[[('a', 1), ('b', 2), ('a', 3), ('b', 4), ('a', 5)], 
# [('b', 6), ('a', 7), ('b', 8), ('a', 9), ('b', 10)]]
print(rdd.glom().collect())
def seqFunc(x,y):
        # seqOp x-> 0
        # seqOp y-> 1
        print("seqOp x->",x)
        print("seqOp y->",y)
        return x + y
def combFunc(x,y):
        #combOp x-> 6
        #combOp y-> 16
        #combOp x-> 9
        #combOp y-> 16
        print("combOp x->",x)
        print("combOp y->",y)
        return x + y
a=rdd.aggregateByKey(0,seqFunc,combFunc)
# [('b', 30), ('a', 25)]
print(a.collect())
##############################################
sc.stop()
