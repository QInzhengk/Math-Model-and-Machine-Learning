import sys
def raiseErr():
    return 1 / 0

try:
    '''需要执行的代码'''
    raiseErr()
except:
    '''有异常捕获，并处理'''
    #Unexpected error: <class 'ZeroDivisionError'>
    print("Unexpected error:", sys.exc_info()[0])
    raise #抛出异常
else:
    '''没有异常执行的代码'''
    print("执行无异常")
finally:
    '''这里不管有没有异常，都会执行'''
    print('=========finally========')