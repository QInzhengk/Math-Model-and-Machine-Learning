
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.range(1,101)
#创建累加器，初始值0
acc = sc.accumulator(0)
def fcounter(x):
        global acc
        if x % 2 == 0 :
                acc += 1
                #unsupported operand type(s) for -=
                #acc -= 1
rdd_counter =  rdd.map(fcounter)
#获取累加器值
#0
print(acc.value)
#保证多次正确获取累加器值
rdd_counter.persist()
#100
print(rdd_counter.count())
#50
print(acc.value)
#100
print(rdd_counter.count())
#50
print(acc.value)
##############################################
sc.stop()