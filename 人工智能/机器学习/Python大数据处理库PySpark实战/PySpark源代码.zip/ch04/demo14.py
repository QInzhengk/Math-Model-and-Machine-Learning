#类定义
class people:
    #定义基本属性
    name = ''
    _age = 0
    #定义私有属性,类外部无法直接进行访问
    __height = 0
    #__init__构造方法
    def __init__(self,name,age,height):
        self.name = name
        self._age = age
        self.__height = height
    def speak(self):
        print("%s age is %d" %(self.name,self._age))
    def _speak(self):
        print("%s height is %d" %(self.name,self.__height))
    #定义私有方法,类外部无法直接进行访问
    def __speak(self):
        print("%s height is %d" %(self.name,self.__height))
 
# 在执行python demo14.py时执行，导入时不执行
if __name__ == '__main__':
    p = people('jack',32,178)
    #jack age is 32
    p.speak()
    #jack height is 178
    p._speak()
    #jack
    print(p.name)
    #32
    print(p._age)
    #'people' object has no attribute '__speak'
    # p.__speak()
    # print(p.__height)
