
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4, 5, 10])
def f(x):
        #1, 2, 3, 4, 5, 10
        print(x)
        #x % 2 的值 0 或 1 ，并作为Key
        return x % 2

rdd = rdd.groupBy(f)
result = rdd.collect()
print(result)
ret = sorted([(x, sorted(y)) for (x, y) in result])
#[(0, [2, 4, 10]), (1, [1, 3, 5])]
print(ret)
##############################################
sc.stop()