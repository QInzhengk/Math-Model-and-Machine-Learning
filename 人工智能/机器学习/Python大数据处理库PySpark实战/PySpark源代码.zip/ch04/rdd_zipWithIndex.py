
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(["a", "b", "c", "d"], 3)
#[('a', 0), ('b', 1), ('c', 2), ('d', 3)]
print(rdd.zipWithIndex().collect())
##############################################
sc.stop()