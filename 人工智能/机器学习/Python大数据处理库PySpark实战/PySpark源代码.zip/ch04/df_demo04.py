
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a = [('Jack', 32),('Smith', 33)]
rdd = sc.parallelize(a)
df = spark.createDataFrame(rdd, "name: string, age: int")
#[Row(name='Jack', age=32), Row(name='Smith', age=33)]
print(df.collect())
df.show()
# +-----+---+
# | name|age|
# +-----+---+
# | Jack| 32|
# |Smith| 33|
# +-----+---+
df.printSchema()
# root
#  |-- name: string (nullable = true)
#  |-- age: integer (nullable = true)

rdd2 = rdd.map(lambda row: row[0])
df2 = spark.createDataFrame(rdd2, "string")
#[Row(value='Jack'), Row(value='Smith')]
print(df2.collect())
df2.show()
# +-----+
# |value|
# +-----+
# | Jack|
# |Smith|
# +-----+
df2.printSchema()
# root
#  |-- value: string (nullable = true)
##############################################
