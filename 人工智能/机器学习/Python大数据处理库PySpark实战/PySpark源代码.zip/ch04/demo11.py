#定义一个say函数，无return返回值
def say(msg) :
    """say函数接受一个参数msg打印出Hello,msg\r\n
    例如say("Python")打印Hello  Python
    """
    print("Hello ",msg)
#None
print(say("Python"))
#定义一个getName函数，return返回值
#先定义函数才能调用
#NameError: name 'getName' is not defined
#print(getName("Python"))
def getName(name) :
    """getName函数接受一个参数name并返回字符串类型的值\r\n
    例如getName("Python")会返回"My Name is Python"
    """
    return "My Name is "+name
#My Name is Python
print(getName("Python"))
#函数作用域实例，函数外是全局变量
msg = "Using "
def getMsg(prefix="Hello ") :
    """getMsg函数参数是一个默认值的参数\r\n
    例如getMsg()会返回"Hello Spark"
    """
    #函数内是局部变量
    msg = "Spark"
    return prefix + msg
#Using Spark
print(getMsg(msg))
#Hello Spark
print(getMsg())
#定义一个可变参数的函数
# *args会存储所有未命名的变量参数,返回元组
def sum( *args ):
   v = 0
   for var in args:
      v += var
   return v
 
#30
print(sum( 10,20 ))
#60
print(sum( 10,20,30 ))
#**vardict也代表可变参数，但参数必须为字段=值的形式
def printinfo(a,*arg, **vardict ):
   print (a)
   print (arg)
   print (vardict)
# 2
# (3, 5)
# {'name': 'jack', 'age': 32}
printinfo(2,3,5,name="jack",age=32)
#2
# (3, 5, 7)
# {'name': 'jack', 'age': 32, 'shool': 'CUMT'}
printinfo(2,3,5,7,name="jack",age=32,shool="CUMT")