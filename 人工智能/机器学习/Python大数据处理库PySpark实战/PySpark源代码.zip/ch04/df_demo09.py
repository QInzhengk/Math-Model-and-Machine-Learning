
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a = [   ('01','张三', '男',32,5000),
        ('01','李四', '男',33,6000),
        ('01','王五', '女',38,5500),
        ('02','Jack', '男',42,7000),
        ('02','Smith', '女',27,6500),
        ('02','Lily', '女',45,9500)
]
rdd = sc.parallelize(a)
peopleDf = spark.createDataFrame(rdd,\
   "deptId:string,name:string,gender:string,age:int,salary:int")
#peopleDf.show()
b = [   ('01','销售部'),
        ('02','研发部')
]
rdd2 = sc.parallelize(b)
deptDf = spark.createDataFrame(rdd2, "id:string,name:string")
#deptDf.show()
#join函数第三个参数默认为inner,其他选项为:
# inner, cross, outer, full, full_outer, left, left_outer, 
# right, right_outer, left_semi, and left_anti.
peopleDf.join(deptDf, peopleDf.deptId == deptDf.id,'inner') \
  .groupBy(deptDf.name, "gender") \
  .agg({"salary": "avg", "age": "max"}) \
  .show()
# +------+------+-----------+--------+
# |  name|gender|avg(salary)|max(age)|
# +------+------+-----------+--------+
# |研发部|    男|     7000.0|      42|
# |销售部|    男|     5500.0|      33|
# |销售部|    女|     5500.0|      38|
# |研发部|    女|     8000.0|      45|
# +------+------+-----------+--------+
##############################################
