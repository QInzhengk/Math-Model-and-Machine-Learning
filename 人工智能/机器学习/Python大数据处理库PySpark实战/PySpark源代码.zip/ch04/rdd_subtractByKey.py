
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
x = sc.parallelize([("a", 1), ("b", 4), ("c", 5), ("a", 3)])
y = sc.parallelize([("a", 7), ("b", 0)])
z = x.subtractByKey(y)
#[('c', 5)]
print(z.collect())
##############################################
sc.stop()