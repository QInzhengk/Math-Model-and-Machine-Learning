
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
#Path : /src/ch04/users.parquet
a = [('Jack', 32),('Smith', 33),('李四', 36)]
rdd = sc.parallelize(a)
df = spark.createDataFrame(rdd, "name: string, age: int")

df.write.parquet("myuser.parquet")
peopleDf = spark.read.parquet("myuser.parquet")
peopleDf.show()
# +-----+---+
# | name|age|
# +-----+---+
# | Jack| 32|
# |Smith| 33|
# | 李四| 36|
# +-----+---+
peopleDf.filter(peopleDf.age > 32).show()
# +-----+---+
# | name|age|
# +-----+---+
# |Smith| 33|
# | 李四| 36|
# +-----+---+
##############################################
