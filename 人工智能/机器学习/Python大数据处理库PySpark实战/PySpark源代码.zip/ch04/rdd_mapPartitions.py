
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4 , 5], 2)
def f(iter): 
        yield sum(iter)

rdd2 = rdd.mapPartitions(f)
#[3, 12]
print(rdd2.collect())
##############################################
sc.stop()