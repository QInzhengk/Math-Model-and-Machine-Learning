
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", ["x", "y", "z"]), ("c", ["w", "m"])])
def f(x): 
        return x
ret = rdd.flatMapValues(f)
#[('a', 'x'), ('a', 'y'), ('a', 'z'), ('c', 'w'), ('c', 'm')]
print(ret.collect())
##############################################
sc.stop()