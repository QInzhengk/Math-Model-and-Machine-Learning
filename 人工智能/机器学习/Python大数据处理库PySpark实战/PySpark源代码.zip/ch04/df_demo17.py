
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
#注意：json数组不能有[]
df = spark.read.format('json') \
        .load('user.json')
#mode : overwrite | append ...
#user.csv不是一个文件，而是一个文件夹
df.write.csv("user.csv","append")
spark.read.csv("user.csv").show()
##############################################
"""
+---+---+---+-----+----+
|_c0|_c1|_c2|  _c3| _c4|
+---+---+---+-----+----+
| 32| 01| 男| 张三|5000|
| 33| 01| 男| 李四|6000|
| 38| 01| 女| 王五|5500|
| 42| 02| 男| Jack|7000|
| 27| 02| 女|Smith|6500|
| 45| 02| 女| Lily|9500|
+---+---+---+-----+----+
"""