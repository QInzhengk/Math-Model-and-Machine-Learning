
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4, 5])
def f(x,y):
        #1 2
        #3 3
        #6 4
        #10 5
        print(x,y)
        return x + y

ret = rdd.reduce(f)
#15 = 1 + 2 + 3 + 4 + 5
print(ret)
def f2(x,y):
        #1 2
        #2 3
        #6 4
        #24 5
        print(x,y)
        return x * y
ret = rdd.reduce(f2)
#120 = 1 * 2 * 3 * 4 * 5
print(ret)
#ValueError: Can not reduce() empty RDD
#sc.parallelize([]).reduce(f)
##############################################
sc.stop()