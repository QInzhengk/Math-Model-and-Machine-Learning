
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([1, 2, 3, 4 ,5 ,6], 3)
def f(index, iter): 
        #分区索引 0,1,2
        print(index)
        for x in iter:
                #1,2;3,4;5,6
                print(x)
        yield index
ret = rdd.mapPartitionsWithIndex(f).sum()
#3=0+1+2
print(ret)
##############################################
sc.stop()