
import findspark
findspark.init()
##############################################

from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[2]") \
        .appName("StreamingContext Demo") \
        .getOrCreate();
sc = spark.sparkContext
from pyspark.streaming import StreamingContext
##3间隔
ssc = StreamingContext(sc, 3)
ssc.checkpoint('spark-ssc-wc')
#############################################
lines = ssc.socketTextStream("localhost", 7777)
words = lines.flatMap(lambda line: line.split(" "))
pairs = words.map(lambda word: (word, 1))
#E:\wmsoft\netcat-win32-1.12>nc -L -v -p 7777
accWordCounts = pairs.countByWindow(6,3)
accWordCounts.pprint()
##############################################
#启动Spark Streaming
ssc.start() 
ssc.awaitTermination()
