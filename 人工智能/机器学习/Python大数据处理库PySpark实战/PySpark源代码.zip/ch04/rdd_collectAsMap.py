
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
m = sc.parallelize([("a", 2), ("b", "c")]).collectAsMap()
print(m["a"])
print(m["b"])
print(m)
#2
# c
# {'a': 2, 'b': 'c'}
##############################################
sc.stop()