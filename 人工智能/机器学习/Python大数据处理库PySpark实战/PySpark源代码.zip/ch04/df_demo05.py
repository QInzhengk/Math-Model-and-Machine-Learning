
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
a = [('Jack', 32),('Smith', 33),('李四', 36)]
rdd = sc.parallelize(a)
df = spark.createDataFrame(rdd, "name: string, age: int")
#3
print(df.count())
df.createOrReplaceTempView("user")
df2 = spark.sql("select count(*) as counter from user")
df2.show()
# +-------+
# |counter|
# +-------+
# |      3|
# +-------+
df2 = spark.sql("select *,age+1 as next from user where age < 36")
df2.show()
# +-----+---+----+
# | name|age|next|
# +-----+---+----+
# | Jack| 32|  33|
# |Smith| 33|  34|
# +-----+---+----+
##############################################
