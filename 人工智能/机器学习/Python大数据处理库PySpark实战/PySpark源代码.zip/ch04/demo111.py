from functools import wraps
 #装饰器(Decorators)logit定义
def logit(func):
    """记录日志使用方法为:\r\n
    @logit\r\n
    def Myfunc([parms]):
    """
    @wraps(func)
    def logging(*args, **kwargs):
        #函数调用前执行
        #(5, 2, 1)
        print(args)
        #{}
        print(kwargs)
        print(func.__name__ + " was called")
        v = func(*args, **kwargs)
        #函数调用后执行
        print(func.__name__ + " run end,value is {0}".format(v))
        return v
    return logging
#装饰器@logit调用
@logit
def sum(x,y,z):
   """求和"""
   return x + y + z

result = sum(5,2,1)
# sum was called
# sum run end,value is 8
# 8
print(result)