# 每隔一段时间生成一个文件,模拟数据文件流的生成
import time
import datetime
# 每n秒执行一次
def timer(n):
    while True:
        print("new file...")
        generate_file()
        time.sleep(n)

def generate_file():
    t = time.strftime('%Y-%m-%d-%H-%M-%S',time.localtime())
    newfile = t + '.txt' 
    f = open("./log/"+newfile,'w')
    f.write("hello pyspark") 
    f.close()

if __name__ == '__main__':
    # 5s
    timer(5)
    