#元组
tuple01 =(1,"hello","python",8.8,True)
#(1, 'hello', 'python', 8.8, True)
print(tuple01)
#<class 'tuple'>
print(type(tuple01))
#元组不支持修改元素，列表可以
#tuple01[0] = 9
#元组只有一个元素,则末尾需要,
tuple01 =(2,)
#<class 'tuple'>
print(type(tuple01)) 
tuple01 =(2)
#<class 'int'>
print(type(tuple01))
#2
print(tuple01)
a = (1,2,3)
b = (4,5,5)
#(1, 2, 3, 4, 5, 5)
print(a+b)
#0
print(b.index(4))
#2
print(b.count(5))
#('h', 'e', 'l', 'l', 'o')
print(tuple("hello"))
#(1, 2, 3, 4, 5)
print(tuple([1, 2, 3, 4 , 5]))
