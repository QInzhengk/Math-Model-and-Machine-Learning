#列表
list = [1,"hello","python",8.8,True]
#python
print(list[2])
#[1, 'hello', 'python', 8.8, True]
print(list[:])
#['hello', 'python']
print(list[1:3])
#['hello', 'python', 8.8, True]
print(list[1:])
#[1, 'hello', 'python']
print(list[:3])
#[1, 'hello', 'python', 8.8, True, 1, 'hello', 'python', 8.8, True]
print(list*2)