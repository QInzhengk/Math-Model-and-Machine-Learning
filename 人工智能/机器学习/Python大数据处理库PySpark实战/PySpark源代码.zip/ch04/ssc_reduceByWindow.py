
import findspark
findspark.init()
##############################################
def sumF(x,y):
        print("x->%s,y->%s",x,y)
        return x+y
def revF(x,y):
        print("x2->%s,y2->%s",x,y)
        return x-y
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[2]") \
        .appName("StreamingContext Demo") \
        .getOrCreate();
sc = spark.sparkContext
from pyspark.streaming import StreamingContext
##3间隔
ssc = StreamingContext(sc, 3)
ssc.checkpoint('spark-ssc-wc')
#############################################
lines = ssc.socketTextStream("localhost", 7777)
words = lines.flatMap(lambda line: line.split(" "))
pairs = words.map(lambda word: 1)
#E:\wmsoft\netcat-win32-1.12>nc -L -v -p 7777
accWordCounts = pairs.reduceByWindow(sumF,revF, 6,3)
accWordCounts.pprint()
##############################################
#启动Spark Streaming
ssc.start() 
ssc.awaitTermination()
