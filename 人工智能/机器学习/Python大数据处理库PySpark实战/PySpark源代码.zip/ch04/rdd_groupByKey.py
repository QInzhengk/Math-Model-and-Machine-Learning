
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
rdd2 = rdd.groupByKey()
def f(x):
        print(x)
        return len(x)

rdd2 = rdd2.mapValues(f)
# [('a', 2), ('b', 1)]
print(rdd2.collect())

def f2(x):
        #print(x)
        return list(x)

#rdd2 = rdd.groupByKey().mapValues(list)
rdd2 = rdd.groupByKey().mapValues(f2)
# [('a', [1, 1]), ('b', [1])]
print(rdd2.collect())
##############################################
sc.stop()