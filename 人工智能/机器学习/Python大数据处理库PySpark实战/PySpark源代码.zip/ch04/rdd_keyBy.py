
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(range(0,3))
#[0, 1, 2]
print(rdd.collect())
def f(x):
        #0, 1, 2
        print(x)
        #0, 1, 4
        return x * x
        
rdd = rdd.keyBy(f)
#[(0, 0), (1, 1), (4, 2)]
print(rdd.collect())
##############################################
sc.stop()