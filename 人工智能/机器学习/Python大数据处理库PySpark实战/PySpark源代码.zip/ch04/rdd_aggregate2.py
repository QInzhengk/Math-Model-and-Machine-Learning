import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
##############################################
data=[1,3,5,7,9,11,13,15,17]
rdd=sc.parallelize(data,2)
def seqOp(x,y):
        print("seqOp x->",x)
        print("seqOp y->",y)
        return (x[0] + y, x[1] + 1)
def combOp(x,y):
        print("combOp x->",x)
        print("combOp y->",y)
        return (x[0] + y[0], x[1] + y[1])
a=rdd.aggregate((0,0),seqOp,combOp)
print(a)
# (81, 9)
##############################################
sc.stop()