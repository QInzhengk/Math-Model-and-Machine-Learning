
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
x = sc.parallelize(range(1,6))
y = sc.parallelize(range(801, 806))
#[(1, 801), (2, 802), (3, 803), (4, 804), (5, 805)]
#x,y长度必须相等
print(x.zip(y).collect())
##############################################
sc.stop()