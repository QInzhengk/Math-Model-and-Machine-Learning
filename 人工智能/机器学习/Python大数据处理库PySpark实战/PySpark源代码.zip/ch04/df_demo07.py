
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
strlen = spark.udf.register("strLen", lambda x: len(x))
a = [('Jack', 32),('Smith', 33),('李四', 36)]
rdd = sc.parallelize(a)
df = spark.createDataFrame(rdd, "name: string, age: int")
df2 = df.select("name").where(strlen("name")>2)
df2.show()
# +-----+
# | name|
# +-----+
# | Jack|
# |Smith|
# +-----+
df2 = df.agg({"age": "max"})
# +--------+
# |max(age)|
# +--------+
# |      36|
# +--------+
df2.show()
df.describe(['age']).show()
# +--------+
# |sum(age)|
# +--------+
# |     101|
# +--------+
df.agg({"age": "sum"}).show()
##############################################
