
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
spark = SparkSession.builder \
        .master("local[1]") \
        .appName("RDD Demo") \
        .getOrCreate();
sc = spark.sparkContext
#############################################
rdd = sc.parallelize(range(100), 1)
ret = rdd.sample(False, 2, 1)
#可能输出[9, 11, 13, 39, 49, 55, 61, 65, 90, 91, 93, 94]
print(ret.collect())
ret = rdd.sample(True, 2, 1)
#可能输出[16, 19, 23, 30, 41, 50, 70, 73, 75, 80, 84, 96, 99]
print(ret.collect())
##############################################
sc.stop()