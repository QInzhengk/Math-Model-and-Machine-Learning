#集合
set01 = {'a', 'ab', 'c', 'd', 'd', 'e'}
#去重
#{'ab', 'd', 'e', 'a', 'c'}
print(set01) 
#True                     
print('ab' in set01)
#TypeError: 'set' object is not subscriptable
#print(set01[1])  
#添加元素，且参数可以是列表，元组，字典
set01.update({'a','cd'})
#{'ab', 'd', 'e', 'cd', 'a', 'c'}
print(set01)  
a = set('abcd')
#{'a', 'd', 'c', 'b'}
print(a) 
#添加元素
a.add(5)
#{5, 'b', 'd', 'a', 'c'}
print(a) 
b = set('adef')
#{'a', 'f', 'e', 'd'}
print(b) 
#添加，有的话无影响
b.add('a')
#{'a', 'f', 'e', 'd'}
print(b)  
#集合a中包含而集合b中不包含的元素  
#{'c', 5, 'b'}                         
print(a - b)                              
# 集合a或b中包含的所有元素
#{5, 'b', 'd', 'f', 'e', 'a', 'c'}
print(a | b)                             
#集合a和b中都包含了的元素
#{'a', 'd'}
print(a & b )                           
#不同时包含于a和b的元素
#{5, 'b', 'f', 'e', 'c'}
print(a ^ b )   
                         
