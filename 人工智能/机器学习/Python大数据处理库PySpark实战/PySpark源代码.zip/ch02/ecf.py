import numpy as np
import matplotlib.pyplot as plt


fig = plt.figure()
x = np.arange(30)
y = 2.5 * np.sin(x / 20 * np.pi)
yerr = np.linspace(-0.2, 0.2, 30)

plt.scatter(x, y + 2+yerr,color="red")
plt.plot(x, y + 2)

plt.show()