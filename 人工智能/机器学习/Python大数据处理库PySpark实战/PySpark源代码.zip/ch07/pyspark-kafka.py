
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

KAFKA_TOPIC_READ = "kf2pyspark"
KAFKA_WRITE_TOPIC = "pyspark2kf"
KAFKA_SERVERS = '127.0.0.1:9092'
JARS_PATH ="file:///E://wmsoft//spark-sql-kafka-0-10_2.11-2.4.0.jar,file:///E://wmsoft//kafka-clients-1.1.0.jar"
if __name__ == "__main__":
    print("PySpark  Kafka  Started ...")
    spark = SparkSession \
        .builder \
        .appName("PySpark Kafka Demo") \
        .master("local[*]") \
        .config("spark.jars", JARS_PATH) \
        .config("spark.executor.extraClassPath", JARS_PATH) \
        .config("spark.executor.extraLibrary", JARS_PATH) \
        .config("spark.driver.extraClassPath", JARS_PATH) \
        .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    #从kf2pyspark主题中读取Kafaka流数据
    sdf = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_SERVERS) \
        .option("subscribe", KAFKA_TOPIC_READ) \
        .option("startingOffsets", "latest") \
        .load()
    #注意Kafaka流数据的格式，业务数据都是在value字段中
    sdf.printSchema()
    sdf = sdf.selectExpr("CAST(value AS STRING)")
   
    bizSchema = StructType() \
        .add("type", StringType()) \
        .add("value", IntegerType()) 
        
    bizDf = sdf.select(from_json(col("value"), bizSchema)\
        .alias("json"))

    #bizDf.printSchema()
    bizDf = bizDf.select("json.*")
    #sdf3.printSchema()
    bizDfCalc = bizDf.groupBy("type")\
        .agg({'value': 'sum'}) \
        .select("type",col("sum(value)").alias("amount"))
        
    #Kafka主题数据必须有value字段
    write_stream = bizDfCalc \
        .select(to_json(struct(col("amount"), col("type"))).alias("value"))\
        .writeStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_SERVERS) \
        .option("topic", KAFKA_WRITE_TOPIC) \
        .option("checkpointLocation", "file:///E:/wmsoft/checkpoints/") \
        .outputMode("complete") \
        .trigger(processingTime='2 seconds') \
        .queryName("sink2kafka")

    query = write_stream.start()
    query.awaitTermination()