import psutil
import time
from threading import Lock
from flask import Flask, render_template
from flask_socketio import SocketIO
from kafka import KafkaConsumer

async_mode = None
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode)
thread = None
thread_lock = Lock()

def bg_task():
    consumer = KafkaConsumer('pyspark2kf', bootstrap_servers=['127.0.0.1:9092'])
    for msg in consumer:
        #print(msg)
        socketio.emit('server_response', 
        {'data': str(msg.value,'utf-8'), 'isOk': 1}
        ,namespace='/kzstream')
        
 
@app.route('/')
def index():
    #templates目录下
    return render_template('index.html', async_mode=socketio.async_mode)

@socketio.on('connect', namespace='/kzstream')
def mtest_connect():
    global thread
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(bg_task)


if __name__ == '__main__':
    socketio.run(app, debug=True)