from kafka import KafkaProducer
import time
import random
import json
from json import dumps
from datetime import datetime
#连接kafka
producer = KafkaProducer(bootstrap_servers='127.0.0.1:9092', \
    value_serializer=lambda x: dumps(x).encode('utf-8'))  
key='streaming'.encode('utf-8')
typeList =['鞋子','裤子','袜子','皮带','化妆品','背包','书籍',
    '零食','运动服','乐器']
#发送内容,必须是bytes类型
for i in range(0, 1000):
    vjson = {}
    for t in typeList:
        i = i + 1
        vjson["bizId"] = str(i)
        vjson["type"] = t
        vjson["value"] = 1
        #vjson["datetime"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print("Message to be sent: ", vjson)
        producer.send('kf2pyspark',value= vjson , key=key)
        time.sleep(1)
producer.flush() 
producer.close()