
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
df_train = spark.read.csv('./data/titanic-train.csv',header=True,inferSchema=True) \
     .cache()
#df_test = spark.read.csv('./data/titanic-test.csv',header=True,inferSchema=True).cache()
#计算基本的统计描述信息
df_train.describe("Age","Pclass","SibSp","Parch").show()
df_train.describe("Sex","Cabin","Embarked","Fare","Survived").show()

pdf = df_train.groupBy('sex','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .orderBy("sex") \
     .toPandas()
#       sex  Survived  count
# 0  female         1    233
# 1  female         0     81
# 2    male         0    468
# 3    male         1    109
print(pdf)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#防止中文乱码
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
width = 0.35
fig, ax = plt.subplots()
labels = ["female",'male']
# print(pdf[pdf["Survived"]== 1])
# print(pdf[pdf["Survived"]== 0])

male_vs =pdf[pdf["Survived"]== 1]["count"]
female_vs = pdf[pdf["Survived"]== 0]["count"]

ax.bar(labels, male_vs, width,  label='Survived')
ax.bar(labels, female_vs, width,  bottom=male_vs,
       label='UnSurvived')
ax.set_ylabel('性别')
ax.set_title('Survived和性别关系分析')
ax.legend()
plt.show()

pdf = df_train.groupBy('Pclass','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
print(pdf)


pdf = df_train.groupBy('Parch','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
print(pdf)

pdf = df_train.groupBy('SibSp','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
print(pdf)
#############################################
sc.stop()