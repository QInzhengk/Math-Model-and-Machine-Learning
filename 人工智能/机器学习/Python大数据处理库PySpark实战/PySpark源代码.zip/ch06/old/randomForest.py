
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, regexp_replace, to_timestamp
from pyspark.ml.feature import StringIndexer
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
df = spark.read.csv('./data/weather-play.csv',header=True,inferSchema=True).cache()
df.printSchema()
df.show()
#字符转成数值
df =df.withColumn("windy",df["windy"].cast("string"))
strindexer = StringIndexer(inputCol="outlook", outputCol="outlookN").fit(df)
df = strindexer.transform(df)
strindexer = StringIndexer(inputCol="temperature", outputCol="tempN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="humidity", outputCol="humidityN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="windy", outputCol="windyN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="play", outputCol="label").fit(df)
df = strindexer.transform(df)
df.show()


#字段转换成特征向量
from pyspark.ml.feature import IndexToString, VectorAssembler, VectorIndexer
from pyspark.ml.classification import  RandomForestClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml import Pipeline
#_c0是序号，排除,features字段名是固定的
df_assembler = VectorAssembler(inputCols=['outlookN','tempN','humidityN','windyN'], outputCol="features")
df = df_assembler.transform(df)

#数据随机拆分
#train, test = df.randomSplit([0.7, 0.3],3)
labelIndexer = StringIndexer(inputCol="label", outputCol="indexedLabel").fit(df)
featureIndexer =\
    VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)

# Split the data into training and test sets (30% held out for testing)
train, test = df.randomSplit([0.7, 0.3],3)

# Train a DecisionTree model.
rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=10)

# Convert indexed labels back to original labels.
labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel",
                                   labels=labelIndexer.labels)

 # Chain indexers and forest in a Pipeline
pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf, labelConverter])

model = pipeline.fit(train)
# Make predictions.
predictions = model.transform(test)
# Select example rows to display.
predictions.select("predictedLabel", "label", "features").show()
# Select (prediction, true label) and compute test error
evaluator = MulticlassClassificationEvaluator(
    labelCol="indexedLabel", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions)
print("Test Error = %g" % (1.0 - accuracy))
rfModel = model.stages[2]
print(rfModel)  # summary only