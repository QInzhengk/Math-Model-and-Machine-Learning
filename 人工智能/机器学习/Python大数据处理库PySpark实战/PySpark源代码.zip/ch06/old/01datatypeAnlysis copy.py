
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, regexp_replace, to_timestamp
from pyspark.ml.feature import StringIndexer
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
df_train = spark.read.csv('./data/titanic-train.csv',header=True,inferSchema=True).cache()
df_train.printSchema()
#行,列数891 12
print(df_train.count(),len(df_train.columns))
#df_train.show()

# df_train_final = df_train.na.drop()
# print(df_train_final.count(),len(df_train_final.columns))
# df_train_final.show()

# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt

from pyspark.sql.functions import col, count, isnan, lit, sum
from numpy import mean


#统计null和nan的数量
def count_null(c):
    pred = col(c).isNull() | isnan(c)
    return sum(pred.cast("integer")).alias(c)


df_train.agg(*[count_null(c) for c in df_train.columns]).show()


df_train2 = df_train.fillna({'Age': 0, 'Cabin': 'unknown'})

age_avg = df_train2.agg({"Age":"avg"}).collect()

#23.79929292929293
#23
#round四舍五入24.0
print(round(age_avg[0][0],0))



#AttributeError: 'NoneType' object has no attribute 'agg'

#df_train2 = df_train.na.fill(subset='Age',value= 0)

# age_avg = df_train2.agg({"Age":"avg"}).collect()

# print(age_avg)

df_train = df_train.fillna({'Age': round(age_avg[0][0],0)})

df_train.agg(*[count_null(c) for c in df_train.columns]).show()

"""


# 使用登录最多的港口来填充登录港口的 nan 值
train_data['Embarked'].fillna('S', inplace=True)
test_data['Embarked'].fillna('S',inplace=True)

# 特征选择
features = ['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']
train_features = train_data[features]
train_labels = train_data['Survived']
test_features = test_data[features]

dvec=DictVectorizer(sparse=False)
train_features=dvec.fit_transform(train_features.to_dict(orient='record'))
print(dvec.feature_names_)

# 构造 ID3 决策树
clf = DecisionTreeClassifier(criterion='entropy')
# 决策树训练
clf.fit(train_features, train_labels)

test_features=dvec.transform(test_features.to_dict(orient='record'))
# 决策树预测
pred_labels = clf.predict(test_features)

# 得到决策树准确率
acc_decision_tree = round(clf.score(train_features, train_labels), 6)
print(u'score 准确率为 %.4lf' % acc_decision_tree)

Titanic_Data
数据集中的字段描述： 
PassengerId 乘客编号 
Survived 是否幸存
 Pclass 船票等级 
 Name 乘客姓名 
 Sex 乘客性别 
 SibSp 亲戚数量（兄妹、配偶数）
  Parch 亲戚数量（父母、子女数） 
  Ticket 船票号码 
  Fare 船票价格
Cabin 船舱 
Embarked 登录港口

"""