
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, regexp_replace, to_timestamp
from pyspark.ml.classification import LogisticRegressionModel
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
lgmodel2 = LogisticRegressionModel.load("./model/logistic-model-breast-cancer")
test = spark.createDataFrame([
    (8,7,5,10,7,9,5,5,4)
],['_c1','_c2','_c3','_c4','_c5','_c6','_c7','_c8','_c9'])
from pyspark.ml.feature import VectorAssembler
#_c0是序号，排除,features字段名是固定的
df_assembler = VectorAssembler(inputCols=['_c1','_c2','_c3','_c4','_c5','_c6','_c7','_c8','_c9'], outputCol="features")
test = df_assembler.transform(test)
#'Field "features" does not exist.\nAvailable fields: _1, _2, _3, _4, _5, _6, _7, _8, _9'
# Make predictions
prediction = lgmodel2.transform(test)
selected = prediction.select("probability", "prediction")
for row in selected.collect():
    prob, prediction = row
    print("prob=%s, prediction=%f" % (str(prob), prediction))
#prob=[0.00037894281995309544,0.9996210571800469], prediction=1.000000
