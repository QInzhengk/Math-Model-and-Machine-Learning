
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.sql.functions import from_unixtime, regexp_replace, to_timestamp
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
df = spark.read.csv('./data/breast-cancer-wisconsin.data',header=False,inferSchema=True).cache()
df.printSchema()
#df.describe().show()
#缺省值处理
df2 = df.filter(df._c6!='?').cache()
print(df2.count())

df2 = df2.withColumn("_c6",df2["_c6"].cast("int"))

#df2.show()
from pyspark.sql.functions import udf
def isMalignant(v):
    if v == 2:
        return 0
    else:
        return 1
from pyspark.sql.types import IntegerType
udf_isMalignant=udf(isMalignant,IntegerType())
df2 = df2.withColumn("_c10",udf_isMalignant(df2["_c10"]))
df2.show()


from pyspark.ml.feature import VectorAssembler
#_c0是序号，排除,features字段名是固定的
df_assembler = VectorAssembler(inputCols=['_c1','_c2','_c3','_c4','_c5','_c6','_c7','_c8','_c9'], outputCol="features")
df2 = df_assembler.transform(df2)

#数据随机拆分
train, test = df2.randomSplit([0.7, 0.3],3)
from pyspark.ml.classification import BinaryLogisticRegressionSummary, LogisticRegression, LogisticRegressionTrainingSummary
from pyspark.ml import PipelineModel
from pyspark.mllib.classification import LogisticRegressionModel
print(train.count())
print(test.count())
#0 和1 都要有分布
train.groupBy('_c10').count().show()
test.groupBy('_c10').count().show()



lg = LogisticRegression(labelCol='_c10')
lgModel = lg.fit(train)
print("Coefficients: \n" + str(lgModel.coefficientMatrix))
print("Intercept: " + str(lgModel.interceptVector))


train_results=lgModel.evaluate(train).predictions
train_results.show()

correct_preds=train_results.filter(train_results['_c10']==1) \
        .filter(train_results['prediction']==1) \
        .count()
#accuracy on training dataset 
print(float(correct_preds)/(train.filter(train['_c10']==1).count()))
results=lgModel.evaluate(test).predictions
results.show()


#lgModel.save("./model/logistic-model-breast-cancer")

print(lgModel)
#print(lg.extractParamMap())

#print(lg.coefficients())
#lg.summary()

#获得回归模型训练的Summary(LogisticRegressionTrainingSummary)
#not lg.summary()
trainingSummary = lgModel.summary
# Obtain the objective per iteration
objectiveHistory = trainingSummary.objectiveHistory
print("objectiveHistory:")
for objective in objectiveHistory:
    print(objective)
# Obtain the receiver-operating characteristic as a dataframe and areaUnderROC.
trainingSummary.roc.show()
print("areaUnderROC: " + str(trainingSummary.areaUnderROC))
# Set the model threshold to maximize F-Measure
fMeasure = trainingSummary.fMeasureByThreshold
maxFMeasure = fMeasure.groupBy().max('F-Measure').select('max(F-Measure)').head()
bestThreshold = fMeasure.where(fMeasure['F-Measure'] == maxFMeasure['max(F-Measure)']) \
    .select('threshold').head()['threshold']

lg.setThreshold(bestThreshold)
#################################
#ROC curve is a plot of FPR against TPR
import matplotlib.pyplot as plt
plt.figure(figsize=(5,5))
plt.plot([0, 1], [0, 1], 'r--')
plt.plot(lgModel.summary.roc.select('FPR').collect(),
         lgModel.summary.roc.select('TPR').collect())
plt.xlabel('FPR')
plt.ylabel('TPR')
plt.show()
##################################
lgmodel2 = LogisticRegressionModel.load(sc,"./model/logistic-model-breast-cancer")

test = spark.createDataFrame([
    (8,7,5,10,7,9,5,5,4)
])

# Make predictions on test documents and print columns of interest.
prediction = lgmodel2.transform(test)
#lgmodel2.predict()

