
import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
df_train = spark.read.csv('./data/titanic-train.csv',header=True,inferSchema=True).cache()
df_test = spark.read.csv('./data/titanic-test.csv',header=True,inferSchema=True).cache()
#计算基本的统计描述信息
df_train.describe("Age","Pclass","SibSp","Parch").show()
df_train.describe("Sex","Cabin","Embarked","Fare","Survived").show()
from pyspark.mllib.stat import Statistics
corr  = Statistics.corr(df_train["Age"], df_train["Pclass"], "pearson")
print(corr)


pdf = df_train.groupBy('sex','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .orderBy("sex") \
     .toPandas()
#       sex  Survived  count
# 0    male         0    468
# 1  female         1    233
# 2  female         0     81
# 3    male         1    109
print(pdf)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#防止中文乱码
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

width = 0.35       # the width of the bars: can also be len(x) sequence



fig, ax = plt.subplots()
labels = ["female",'male']


print(pdf[pdf["Survived"]== 1])

print(pdf[pdf["Survived"]== 0])



male_vs =pdf[pdf["Survived"]== 1]["count"]
female_vs = pdf[pdf["Survived"]== 0]["count"]


ax.bar(labels, male_vs, width,  label='Survived')
ax.bar(labels, female_vs, width,  bottom=male_vs,
       label='UnSurvived')

ax.set_ylabel('性别')
ax.set_title('Survived和性别关系分析')
ax.legend()

plt.show()




pdf = df_train.groupBy('Pclass','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
#    Pclass  Survived  count
# 0       1         0     80
# 1       3         1    119
# 2       1         1    136
# 3       2         1     87
# 4       2         0     97
# 5       3         0    372
print(pdf)


pdf = df_train.groupBy('Parch','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
#     Parch  Survived  count
# 0       1         0     53
# 1       3         1      3
# 2       6         0      1
# 3       4         0      4
# 4       1         1     65
# 5       0         0    445
# 6       2         1     40
# 7       0         1    233
# 8       2         0     40
# 9       5         0      4
# 10      5         1      1
# 11      3         0      2
print(pdf)

pdf = df_train.groupBy('SibSp','Survived') \
     .agg({'PassengerId': 'count'}) \
     .withColumnRenamed("count(PassengerId)","count") \
     .toPandas()
    # SibSp  Survived  count
# 0       1         0     97
# 1       3         1      4
# 2       4         0     15
# 3       1         1    112
# 4       0         0    398
# 5       2         1     13
# 6       0         1    210
# 7       2         0     15
# 8       5         0      5
# 9       8         0      7
# 10      3         0     12
# 11      4         1      3
print(pdf)




#############################################
sc.stop()