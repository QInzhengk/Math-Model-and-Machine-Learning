import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.ml.feature import StringIndexer
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
df = spark.read.csv('./data/weather-play.csv',header=True,inferSchema=True).cache()
df.printSchema()
df.show()
#字符转成数值
df =df.withColumn("windy",df["windy"].cast("string"))

strindexer = StringIndexer(inputCol="outlook", outputCol="outlookN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="temperature", outputCol="tempN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="humidity", outputCol="humidityN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="windy", outputCol="windyN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="play", outputCol="label").fit(df)
df = strindexer.transform(df)
df.show()


#字段转换成特征向量
from pyspark.ml.feature import  VectorAssembler
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.classification import MultilayerPerceptronClassifier
#_c0是序号，排除,features字段名是固定的
df_assembler = VectorAssembler(inputCols=['outlookN','tempN','humidityN','windyN'], outputCol="features")
df = df_assembler.transform(df)



# Split the data into training and test sets (30% held out for testing)
(train, test) = df.randomSplit([0.7, 0.3],3)
# specify layers for the neural network:
# input layer of size 4 (features), two intermediate of size 5 and 4
# and output of size 3 (classes)
#layers = [4, 5, 4, 3]
#需要根据情况调整
layers = [4, 5, 4, 2]
# create the trainer and set its parameters
trainer = MultilayerPerceptronClassifier(maxIter=100, layers=layers, blockSize=128, seed=1234)
# train the model
model = trainer.fit(train)
# compute accuracy on the test set
result = model.transform(test)
predictionAndLabels = result.select("prediction", "label")
evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
print("Test set accuracy = " + str(evaluator.evaluate(predictionAndLabels)))