import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.ml.feature import StringIndexer
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.classification import SVMWithSGD
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
def parsePoint(row):
    #Row(label=1.0, outlookN=1.0, tempN=2.0, humidityN=0.0, windyN=0.0)
    print(row)
    values = [float(c) for c in row]
    return LabeledPoint(values[0], values[1:])
#rdd = sc.textFile("./data/weather-play.csv")
#parsedData = rdd.map(parsePoint)

df = spark.read.csv('./data/weather-play.csv',header=True,inferSchema=True).cache()
df.printSchema()
df.show()
#字符转成数值
df =df.withColumn("windy",df["windy"].cast("string"))

strindexer = StringIndexer(inputCol="outlook", outputCol="outlookN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="temperature", outputCol="tempN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="humidity", outputCol="humidityN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="windy", outputCol="windyN").fit(df)
df = strindexer.transform(df)

strindexer = StringIndexer(inputCol="play", outputCol="label").fit(df)
df = strindexer.transform(df)
df.show()
df = df.select("label","outlookN","tempN","humidityN","windyN")
rdd = df.rdd
parsedData = rdd.map(parsePoint)
print(parsedData)

# Build the model
model = SVMWithSGD.train(parsedData, iterations=100)
# Evaluating the model on training data
labelsAndPreds = parsedData.map(lambda p: (p.label, model.predict(p.features)))
trainErr = labelsAndPreds.filter(lambda lp: lp[0] != lp[1]).count() / float(parsedData.count())
print("Training Error = " + str(trainErr))

print(labelsAndPreds.collect())
#[(1.0, 1), (1.0, 1), (0.0, 0), (0.0, 0), (0.0, 0), (1.0, 1), (0.0, 0), (1.0, 0), (0.0, 0), (0.0, 0), (0.0, 0), (0.0, 0), (0.0, 0), (1.0, 1)]