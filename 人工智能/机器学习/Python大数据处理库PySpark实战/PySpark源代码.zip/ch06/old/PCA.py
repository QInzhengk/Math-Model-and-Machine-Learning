import findspark
findspark.init()
##############################################
from pyspark.sql import SparkSession
from pyspark.sql.context import SQLContext
from pyspark.ml.feature import PCA, StringIndexer
from pyspark.ml.linalg import Vectors
spark = SparkSession.builder \
        .master("local[*]") \
        .appName("PySpark ML") \
        .getOrCreate()
sc = spark.sparkContext
#############################################
sqlContext=SQLContext(sc)
data = [(Vectors.sparse(5, [(1, 1.0), (3, 7.0)]),),
        (Vectors.dense([2.0, 0.0, 3.0, 4.0, 5.0]),),
        (Vectors.dense([4.0, 0.0, 0.0, 6.0, 7.0]),)]
df = spark.createDataFrame(data, ["features"])
pca = PCA(k=3, inputCol="features", outputCol="pcaFeatures")
model = pca.fit(df)
result = model.transform(df).select("pcaFeatures")
result.show(truncate=False)
# +-----------------------------------------------------------+
# |pcaFeatures                                                |
# +-----------------------------------------------------------+
# |[1.6485728230883807,-4.013282700516296,-5.524543751369388] |
# |[-4.645104331781534,-1.1167972663619026,-5.524543751369387]|
# |[-6.428880535676489,-5.337951427775355,-5.524543751369389] |
# +-----------------------------------------------------------+