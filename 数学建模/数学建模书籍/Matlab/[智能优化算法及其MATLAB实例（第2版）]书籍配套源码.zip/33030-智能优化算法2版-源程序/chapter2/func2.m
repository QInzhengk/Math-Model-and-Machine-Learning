%%%%%%%%%%%%%%%%%%%%%%%%%%%��Ӧ�Ⱥ���%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result=func2(x)
summ=sum(x.^2);
result=summ;
