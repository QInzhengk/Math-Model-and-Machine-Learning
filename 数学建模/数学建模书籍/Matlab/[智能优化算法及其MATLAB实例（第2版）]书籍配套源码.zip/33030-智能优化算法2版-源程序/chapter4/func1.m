%%%%%%%%%%%%%%%%%%%%%%%%%�׺ͶȺ���%%%%%%%%%%%%%%%%%%%%%%
function result=func1(x)
summ=sum(x.^2);
result=summ;
