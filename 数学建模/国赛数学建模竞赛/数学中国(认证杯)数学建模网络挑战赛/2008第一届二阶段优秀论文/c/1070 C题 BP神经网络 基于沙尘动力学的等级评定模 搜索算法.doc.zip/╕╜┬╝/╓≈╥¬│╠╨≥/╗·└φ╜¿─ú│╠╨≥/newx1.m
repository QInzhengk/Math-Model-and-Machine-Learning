function y=newx1(x,x1mu,x1sigma)
global x1mu x1sigma;
y=normcdf(x,x1mu,x1sigma);
