x1mu=4*kst*u0+4*st0-4*sta0;
x1sigma=4*a*usigma.^2+4*kstasigma.^2;
x2mu=sta0-stg0-0.608*k*kst*k1*l0*u0-0.608*k*k1*st0*ldown0+0.608*k*st0*k1*lup0-0.608*k*st0*l0*k1;
x2sima=stasigma.^2+stgsigma.^2+0.608*k*kst*k1*l0*usigma.^2+0.608*k*k1*st0*ldownsigma.^2+0.608*k*st0*k1*lupsigma.^2+0.608*k*st0*k1*lupsigma.^2;