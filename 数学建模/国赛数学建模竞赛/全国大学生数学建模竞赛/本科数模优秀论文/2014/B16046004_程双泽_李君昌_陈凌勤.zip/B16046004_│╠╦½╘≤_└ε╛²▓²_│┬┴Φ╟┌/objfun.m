function f=objfun(ts)
f=-sin(ts(1));
%di er mubiao
%l=w+h/sin(ts(1));
%d=l-ts(2);
%q=32.5-abs(x);  
%len=sqrt(d^2-+w^2+q^2-2*(d*cos(ts(1))+w)*q+2*d*w*cos(ts(1)))+q-d-w
%f=sum(len);