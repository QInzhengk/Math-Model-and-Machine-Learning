function w=lv(x)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
for i=1:47;
    w(i)=x(i,1)./sum(x(:,1))
end   

end

