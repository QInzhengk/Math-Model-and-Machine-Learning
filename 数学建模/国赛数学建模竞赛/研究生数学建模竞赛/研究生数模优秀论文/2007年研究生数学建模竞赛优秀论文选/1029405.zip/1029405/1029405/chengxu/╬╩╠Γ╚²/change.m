temp=0;
temp=[W(1,:);W(36,:);W(59:64,:);W(66:74,:);W(75:79,:)];
temp=temp';
temp=[temp(1,:);temp(36,:);temp(59:64,:);temp(66:74,:);temp(75:79,:)];
%temp;
%temp=[temp(end,:);temp(1:end-1,:)];
%temp=temp';
%temp=[temp(end,:);temp(1:end-1,:)]