function y1=line()
y1=(symsum((symsum((symsum((symsum(Sx1jk(i)+SAx1jk(i)-SMx1jk(i),1,4)),,1,4)),1,4))),1,a1)

+symsum((symsum((symsum((symsum(Sx2jk(i)+SAx2jk(i)-SMx2jk(i),1,4)),,1,4)),1,4))),1,a2)
+symsum((symsum((symsum((symsum(Sx3jk(i)+SAx3jk(i)-SMx3jk(i),1,4)),,1,4)),1,4))),1,a3))
*(T-ti)
