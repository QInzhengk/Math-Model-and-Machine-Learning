function S2=net()
L=6;
S2=symsum(symsum((symsum((symsum((symsum(Sxljk(i)+SAxljk(i)-SMxljk(i),1,4)),,1,4)),1,4))),1,al)(T-al*Tl),1,L)