clear
clc
Name = [1203959,
        1504519,
        1811345,
        1812492,
        1923252,
        1928033];
        
for i = 1:length(Name)
    rrr(i) = ComSameBul(Name(i));
end