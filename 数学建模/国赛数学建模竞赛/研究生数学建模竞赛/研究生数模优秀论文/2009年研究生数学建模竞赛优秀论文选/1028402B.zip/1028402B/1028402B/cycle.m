clear
clc
for i=1:22
    for j=i+1:22
        maxr(i,j)=ComDiffBul(i,j);
    end
    i
end