# mcm_template
my latex mcm template(add subiles,todonotes,and so on). 我修改的数学建模美赛模板
