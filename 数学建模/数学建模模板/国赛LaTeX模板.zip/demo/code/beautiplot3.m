function beautiplot3()
ax =gca;
set(ax,'XGrid','on','YGrid','on','GridLineStyle','--','GridAlpha',0.15);
set(ax,'Box','off','LineWidth',1.5);
set(ax,'XMinorTick','on','YMinorTick','on');
end